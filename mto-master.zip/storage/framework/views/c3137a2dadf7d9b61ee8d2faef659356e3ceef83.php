<?php $__env->startSection('content'); ?>

    <div class="card" style="width:20rem;">
        <form class="form-signin" method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <img class="mb-4" src="<?php echo e(asset('/images/S png.png')); ?>" alt="Error" width="72" height="72">
            <h1 class="h3 mb-3 font-weight-normal">Bienvenido</h1>
            <label for="mail" class="sr-only">Correo</label>
            <input name="email" type="email" id="mail" class="form-control" placeholder="Correo Electronico" required autofocus>
            <br>
            <label for="password" class="sr-only">Contraseña</label>
            <input name="password" type="password" id="password" class="form-control" placeholder="Contraseña" required>
            <div class="checkbox mb-3">

                <label>
                    <input type="checkbox" value="remember-me"> Recuerdame
                </label>

            </div>
            <button type="submit" class="btn btn-lg btn-primary btn-block">
                <?php echo e(__('Entrar')); ?>

            </button>
            <br>

            <?php if(Route::has('password.request')): ?>
                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                    <?php echo e(__('¿Recuperar Contraseña?')); ?>

                </a>
            <?php endif; ?>
            
            

        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutlogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mto-master\resources\views/auth/login.blade.php ENDPATH**/ ?>