<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SSTECNOLOGIC SPA</title>

    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('/images/S png.png')); ?>">
    <link rel="shortcut icon" sizes="192x192" href="<?php echo e(asset('/images/S png.png')); ?>">

    
    
    <!-- Google Font: Source Sans Pro -->
    
    <!-- Font Awesome -->
    
    <!-- overlayScrollbars -->
    
    <!-- Theme style -->
    <link rel="stylesheet" href="../../dist/css/adminlte.min.css">

    

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('css/signin.css')); ?>"  rel="stylesheet">
    <style>
        /* p {
            font-size: 14px;
        } */

        BODY {
            background-image: url(/images/fondo.jpg);
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

    </style>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<Body class="text-center" background="../mto-master/public/images/fondo.jpg">
    <div>
        
        <div>
            <section class="content">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </div>
    </div>
</body>


<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
crossorigin="anonymous"></script>

<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"
        integrity="sha512-F636MAkMAhtTplahL9F6KmTfxTmYcAcjcCkyu0f0voT3N/6vzAuJ4Num55a0gEJ+hRLHhdz3vDvZpf6kqgEa5w=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<?php echo $__env->yieldContent('scripts'); ?>

</html>
<?php /**PATH C:\xampp\htdocs\mto-master\resources\views/layouts/layoutlogin.blade.php ENDPATH**/ ?>