

<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <div class="row">
            <div class="col-sm-12">
                <?php if(session('message')): ?>
                    <div class="alert alert-success"><?php echo e(session('message')); ?><button type="button" class="close"
                            data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                <?php if(session('messageerror')): ?>
                    <div class="alert alert-danger"><?php echo e(session('messageerror')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <form id="ingresoHonor" action="<?php echo e(route('formHonor.store')); ?>" enctype="multipart/form-data"
                    method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card card-blue">
                                    <div class="card-header">
                                        <h3 class="card-title">Prestador</h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <ul style="list-style-type: none">
                                                    <li>
                                                        <label>Rut:</label>
                                                        <input id="rut" name="rut" type="text" class="form-control"
                                                            placeholder="Rut con guión y sin puntos" required>
                                                        <br>
                                                    </li>
                                                    <li>
                                                        <label>Teléfono</label>
                                                        <input type="number" id="telefono" name="telefono"
                                                            class="form-control" required>
                                                        <br>
                                                    </li>
                                                    <li>
                                                        <label>Region:</label>
                                                        <select id="region_cat" name="region_cat" class="form-control">
                                                            <option value="" disabled selected>Elija una región</option>
                                                            <?php $__currentLoopData = $reg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->nombre); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <br>
                                                    </li>
                                                    <li>
                                                        <label>Comuna:</label>
                                                        <select id="comuna_cat" name="comuna_cat" class="form-control">
                                                            <option value="" disabled selected>Seleccione una comuna
                                                            </option>
                                                        </select>
                                                        <br>
                                                    </li>
                                                    <li>
                                                        <label>Dirección:</label>
                                                        <input id="direccion" name="direccion" type="text"
                                                            class="form-control" placeholder="Ingrese su dirección"
                                                            required>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="col-md-6">
                                                <ul style="list-style-type: none">
                                                    <li>
                                                        <label>Nombre:</label>
                                                        <input type="text" id="nombre" value="" name="nombre"
                                                            class="form-control" placeholder="Nombre" required>
                                                        <br>
                                                    </li>
                                                    <li>
                                                        <label>Apellido Paterno:</label>
                                                        <input type="text" id="apellidoP" value="" name="apellidoP"
                                                            class="form-control" placeholder="Nombre" required>
                                                        <br>
                                                    </li>
                                                    <li>
                                                        <label>Apellido Materno:</label>
                                                        <input type="text" id="apellidoM" value="" name="apellidoM"
                                                            class="form-control" placeholder="Nombre" required>
                                                        <br>
                                                    </li>
                                                    <li>
                                                        <label>Email:</label>
                                                        <input type="email" id="email" name="email" class="form-control"
                                                            placeholder="ejemplo@gmail.com" required>
                                                        <br>
                                                    </li>
                                                    <li>
                                                        <label>Cargo:</label>
                                                        <select id="cargo" name="cargo" class="form-control">
                                                            <option value="" disabled selected>Elija un cargo</option>
                                                            <?php $__currentLoopData = $cargos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($car->id); ?>">
                                                                    <?php echo e($car->nombre_cargos); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </li>
                                                </ul>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="card card-blue">
                            <div class="card-header">
                                <h3 class="card-title">Como Empresa</h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <ul style="list-style-type: none">
                                            <li>
                                                
                                            </li>
                                            <li>
                                                <label>Teléfono:</label>
                                                <input type="number" id="telefonoE" name="telefonoE" class="form-control"
                                                    Required>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="col-md-6">
                                        <ul style="list-style-type: none">
                                            <li>
                                                <label>Dirección:</label>
                                                <input type="text" id="direccionE" name="direccionE" class="form-control"
                                                    Required>
                                                <br>
                                            </li>
                                            <li>
                                                <label>Razon Social:</label>
                                                <input type="text" id="razonSocial" name="razonSocial" class="form-control"
                                                    Required>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="float-lg-right">
                                            <button class="btn btn-primary" class="submit" id="enviar">Guardar</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

                <form id="ingresoDocumento" action="<?php echo e(route('formHonor.store')); ?>" enctype="multipart/form-data" method="POST">
                    
                    <!--Documentos-->
                    
                    <div class="col-md-12">
                        <div class="card card-info">
                            <div class="card-header">
                                <h3 class="card-title">Documentos</h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="card col-md-4">
                                        <ul style="list-style-type: none">
                                            <li>
                                                <label>Fecha:</label><br>
                                                <input type="date" id="fecha" name="fechaCompra" min="2000-01-01" style="width: 240px" max="<?php echo date('Y-m-d'); ?>" value="<?php echo date('Y-m-d'); ?>">
                                                <br>
                                                <br>
                                            </li>
                                            <li>
                                                <label>Periodo:</label><br>
                                                <input style="width: 240px" type="month" id="periodo" name="periodo" min="2000-01" max="2050-07" value="<?php echo date('Y-m'); ?>">
                                                <br>
                                                <br>
                                            </li>
                                            <li>
                                                <label>Plazo:</label><br>
                                                <input style="width: 240px" type="DATE" id="plazo" name="plazo" value="<?php echo date('Y-m-d'); ?>">
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="card col-md-4">
                                        <ul style="list-style-type: none">
                                            <li>
                                                <label>Vencimiento:</label><br>
                                                <input style="width: 240px" type="DATE" id="vencimiento" name="vencimiento" value="<?php echo date('Y-m-d'); ?>">
                                                <br>
                                                <br>
                                            </li>
                                            <li>
                                                <label>Número de documento:</label><br>
                                                <input style="width: 240px" type="number" id="Ndocumento" name="numeroDocumento" Required>
                                                <br>
                                                <br>
                                            </li>
                                            <li>
                                                <label>Tipo de documento:</label>
                                                <br>
                                                <select style="width: 240px" id="tipoDoc" class="form-select" Required>
                                                    <option value="" disable selected>--seleccionar tipo de documento--</option>
                                                    <?php $__currentLoopData = $tipo_documento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($tipo->id); ?>">
                                                            <?php echo e($tipo->nombre_tipo_documento_honorario); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="card col-md-4">
                                        <ul style="list-style-type: none">
                                            <li>
                                                <label>Comentario:</label>
                                                <textarea style="width: 240px" class="form-control" id="Nota" Required></textarea>
                                                <br>
                                                <br>
                                            </li>
                                            <li>
                                                <label>Tipos de pago:</label>
                                                <br>
                                                <select style="width: 240px" id="tipoPago" class="form-select" Required>
                                                    <option value="" disable selected>--seleccionar metodo de pago--</option>
                                                    <?php $__currentLoopData = $forma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($f->id); ?>">
                                                            <?php echo e($f->nombre_forma_pago); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                </select>
                                                <br>
                                                <br>
                                            </li>
                                            <li>
                                                <label>Documento:</label>
                                                <input class="form-control" style="width: 240px" accept="" type="file" id="fini_file" name="fini_file">
                                            </li>
                                        </ul>  
                                    </div>
                                </div>
                                <div class="float-lg-right">
                                    <button class="btn btn-primary" class="submit" name="enviarArchivo"
                                        id="enviarArchivo">Guardar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    

                </form>
            </div>
    </section>

    <script type="text/javascript">
        //formateador Rut

        $('#rut').change(function() {
            var rut = $('#rut').val()
            console.log(rut)

            var asd = rut.substr(rut.length - 1, rut.length)
            var asd3 = dgv(rut.substr(0, rut.length - 1))

            $.ajax({
                type: 'get',
                url: '<?php echo URL::to('formatoRut'); ?>',
                data: {
                    'rut': rut
                },

                success: function(data) {
                    // despejar punto
                    var valor = rut.replace('.', '');
                    // Despejar Guión
                    valor = valor.replace('-', '');
                    valor = valor.replace('.', '');
                    // Aislar Cuerpo y Dígito Verificador
                    var cuerpo = valor.slice(0, -1);

                    var dv = valor.slice(-1).toUpperCase();
                    var rutformato = cuerpo.substr(0, 2) + "." + cuerpo.substr(
                            2,
                            3) + "." + cuerpo.substr(5, cuerpo.length) + "-" +
                        dv;
                    document.getElementById("rut").value = rutformato;

                    $.ajax({
                        type: 'get',
                        url: '<?php echo URL::to('rutFinder'); ?>',
                        data: {
                            'rut': rutformato
                        },
                        success: function(data) {
                            console.log(data);
                            document.getElementById("nombre").value = data[0]
                                .nombre_prestador;
                            document.getElementById("apellidoP").value = data[0]
                                .apellido_p_prestador;
                            document.getElementById("apellidoM").value = data[0]
                                .apellido_m_prestador;
                            document.getElementById("email").value = data[0]
                            .email_prestador;
                            document.getElementById("telefono").value = data[0]
                                .telefono_prestador;
                            document.getElementById("direccion").value = data[0]
                                .direccion_prestador;
                            document.getElementById("razonSocial").value = data[0]
                                .razon_social_prestador;
                            document.getElementById("direccionE").value = data[0]
                                .direccion_empresa_prestador;
                            document.getElementById("telefonoE").value = data[0]
                                .telefono_empresa_prestador;
                            document.getElementById("cargo").value = data[0].cargos_id;
                            $('#region_cat').val(data[0].region);
                            $('#comuna_cat').val(data[0].comuna_id);

                            var idowner = data[0].id;
                        },
                        error: function(data) {
                            console.log('Nuevo Ingreso')
                        }
                    });
                },
                error: function() {

                }
            });

            function dgv(T) //digito verificador
            {
                var M = 0,
                    S = 1;
                for (; T; T = Math.floor(T / 10))
                    S = (S + T % 10 * (9 - M++ % 6)) % 11;
                return S ? S - 1 : 'k';
            }
        });

        $(document).ready(function() {
            //Cambio de regiones y comunas
            $(document).on('change', '#region_cat', function() {
                //console.log("Cambio");

                var region_cat = $(this).val();
                //console.log(region_cat)
                var div = $(this).parent();
                var op = " ";
                $.ajax({
                    type: 'get',
                    url: '<?php echo URL::to('findComuna'); ?>',
                    data: {
                        'id': region_cat
                    },
                    success: function(data) {
                        console.log('success');

                        console.log(data);

                        console.log(data.length);
                        op += '<option value="0" selected disabled>Elija comuna</option>';
                        for (var i = 0; i < data.length; i++) {
                            op += '<option value="' + data[i].id + '">' + data[i].nombre +
                                '</option>';
                        }
                        $('#comuna_cat').html(" ");
                        $('#comuna_cat').append(op);
                    },
                    error: function() {

                    }
                });
            });


            // $(document).on('change', '#rut', function() {

            //     var rut = $(this).val();
            //     console.log(rut);

            //     $.ajax({
            //         type: 'get',
            //         url: '<?php echo URL::to('rutFinder'); ?>',
            //         data: {
            //             '': rut
            //         },
            //         success: function(data) {
            //             console.log(data);
            //             document.getElementById("nombre").value = data[0].nombre_prestador;
            //             document.getElementById("apellidoP").value = data[0].apellido_p_prestador;
            //             document.getElementById("apellidoM").value = data[0].apellido_m_prestador;
            //             document.getElementById("email").value = data[0].email_prestador;
            //             document.getElementById("telefono").value = data[0].telefono_prestador;
            //             document.getElementById("direccion").value = data[0].direccion_prestador;
            //             document.getElementById("razonSocial").value = data[0].razon_social_prestador;
            //             document.getElementById("direccionE").value = data[0].direccion_empresa_prestador;
            //             document.getElementById("telefonoE").value = data[0].telefono_empresa_prestador;
            //             document.getElementById("cargo").value = data[0].cargos_id;
            //             $('#region_cat').val(data[0].region);
            //             $('#comuna_cat').val(data[0].comuna);

            //             var idowner = data[0].id;
            //         },
            //         error: function(data) {
            //             console.log('Nuevo Ingreso')
            //         }
            //     });
            // });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mto-master\resources\views/Honorarios/formHonor.blade.php ENDPATH**/ ?>